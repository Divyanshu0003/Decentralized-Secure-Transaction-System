import React, { useState, useEffect } from "react"; // ✅ Correct import
import { ethers } from "ethers";
import { motion } from "framer-motion";

const provider = new ethers.JsonRpcProvider("http://127.0.0.1:8545"); // ✅ Local blockchain
const privateKey = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"; // ✅ Local wallet
const wallet = new ethers.Wallet(privateKey, provider);

function App() {
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [status, setStatus] = useState("");
  const [transactions, setTransactions] = useState([]);

  const initialRecipients = [
    { nickname: "Alice", address: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8" },
    { nickname: "Bob", address: "0x3C44CdDdB6A900fa2b585dd299e03d12FA4293BC" },
    { nickname: "Charlie", address: "0x90F79bf6EB2c4f870365E785982E1f101E93b906" },
    { nickname: "David", address: "0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65" },
    { nickname: "Eve", address: "0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc" },
    { nickname: "Frank", address: "0x976EA74026E726554dB657fA54763abd0C3a0aa9" },
    { nickname: "Grace", address: "0x14dC79964da2C08b23698B3D3cc7Ca32193d9955" },
    { nickname: "Hank", address: "0x23618e81E3f5cdF7f54C3d65f7FBc0aBf5B21E8f" },
    { nickname: "Ivy", address: "0xa0Ee7A142d267C1f36714E4a8F75612F20a79720" },
    { nickname: "Jack", address: "0xBcd4042DE499D14e55001CcbB24a551F3b954096" },
    { nickname: "Kate", address: "0x71bE63f3384f5fb98995898A86B02Fb2426c5788" },
    { nickname: "Leo", address: "0xFABB0ac9d68B0B445fB7357272Ff202C5651694a" },
    { nickname: "Mia", address: "0x1CBd3b2770909D4e10f157cABC84C7264073C9Ec" },
    { nickname: "Nate", address: "0xdF3e18d64BC6A983f673Ab319CCaE4f1a57C7097" },
    { nickname: "Olivia", address: "0xcd3B766CCDd6AE721141F452C550Ca635964ce71" },
    { nickname: "Paul", address: "0x2546BcD3c84621e976D8185a91A922aE77ECEc30" },
    { nickname: "Quinn", address: "0xbDA5747bFD65F08deb54cb465eB87D40e51B197E" },
    { nickname: "Ryan", address: "0xdD2FD4581271e230360230F9337D5c0430Bf44C0" },
    { nickname: "Sophia", address: "0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199" }
  ];

  const [filteredRecipients, setFilteredRecipients] = useState(initialRecipients);

  useEffect(() => {
    fetchTransactions();
    provider.on("block", fetchTransactions);
    return () => provider.off("block", fetchTransactions);
  }, []);

  const fetchTransactions = async () => {
    try {
      const latestBlockNumber = await provider.getBlockNumber();
      const txList = [];

      for (let i = latestBlockNumber; i >= Math.max(0, latestBlockNumber - 50); i--) {
        const block = await provider.getBlockWithTransactions(i);
        if (!block) continue;
        block.transactions.forEach((tx) => {
          const fromAddress = tx.from ? tx.from.toLowerCase() : null;
          const toAddress = tx.to ? tx.to.toLowerCase() : null;

          if (fromAddress === wallet.address.toLowerCase() || toAddress === wallet.address.toLowerCase()) {
            txList.push(tx);
          }
        });
      }

      setTransactions(txList.reverse());
    } catch (error) {
      console.error("Error fetching transactions:", error);
    }
  };

  const sendTransaction = async () => {
    const matchedRecipient = initialRecipients.find(r => r.nickname.toLowerCase() === recipient.toLowerCase());
    const recipientAddress = matchedRecipient ? matchedRecipient.address : recipient;

    if (!ethers.isAddress(recipientAddress)) {
      setStatus("❌ Invalid recipient address!");
      return;
    }

    try {
      if (isNaN(amount) || parseFloat(amount) <= 0) {
        setStatus("❌ Enter a valid amount!");
        return;
      }

      const tx = await wallet.sendTransaction({
        to: recipientAddress,
        value: ethers.parseEther(amount.toString()),
      });

      setStatus("🚀 Transaction Sent! Waiting for confirmation...");
      await tx.wait();
      setStatus(`✅ Transaction Successful: ${tx.hash}`);

      fetchTransactions();
    } catch (error) {
      console.error("❌ Error:", error);
      setStatus(`❌ Transaction Failed! ${error.message}`);
    }
  };

  const handleRecipientChange = (e) => {
    const input = e.target.value;
    setRecipient(input);
    setFilteredRecipients(
      initialRecipients.filter(r =>
        r.nickname.toLowerCase().includes(input.toLowerCase()) ||
        r.address.toLowerCase().includes(input.toLowerCase())
      )
    );
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-900 to-purple-900 text-white p-6">
      <motion.div
        className="max-w-2xl w-full bg-gray-800 p-6 rounded-xl shadow-2xl"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-green-400 to-blue-500 text-transparent bg-clip-text">
          💰 Send ETH Securely
        </h1>

        {/* Recipient & Amount Section */}
        <div className="flex items-center space-x-2">
          {/* Recipient Input */}
          <div className="relative flex-1">
            <input
              type="search"
              placeholder="Enter recipient name"
              className="w-full px-4 py-3 rounded-lg bg-gray-700 border border-gray-600 text-white outline-none focus:ring-2 focus:ring-green-400 transition duration-300 ease-in-out"
              value={recipient}
              onChange={handleRecipientChange}
            />
            {/* Dropdown for recipient suggestions */}
            {recipient && filteredRecipients.length > 0 && (
              <div className="absolute w-full bg-gray-800 rounded-md shadow-md mt-1 z-10 max-h-40 overflow-y-auto">
                {filteredRecipients.map((r, index) => (
                  <div
                    key={index}
                    className="p-2 hover:bg-gray-600 cursor-pointer transition duration-200"
                    onClick={() => setRecipient(r.nickname)} // Set the nickname instead of address
                  >
                    <span className="font-semibold text-green-400">{r.nickname}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Amount Input */}
          <input
            type="text"
            placeholder="Amount in ETH"
            className="w-36 px-4 py-3 rounded-lg bg-gray-700 border border-gray-600 text-white outline-none focus:ring-2 focus:ring-green-400 transition duration-300 ease-in-out"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />

          {/* Send Button */}
          <motion.button
            onClick={sendTransaction}
            className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105"
          >
            Send 🚀
          </motion.button>
        </div>

        {/* Status Message */}
        <p className="mt-4 text-center text-yellow-300">{status}</p>

        {/* Transaction History */}
        <h2 className="text-xl font-semibold mt-6">📜 Transaction History</h2>
        <motion.div
          className="mt-2 bg-gray-700 p-4 rounded-lg max-h-60 overflow-auto space-y-3"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          {transactions.length === 0 ? (
            <p className="text-gray-400 text-center">No transactions found.</p>
          ) : (
            transactions.map((tx, index) => (
              <motion.div
                key={index}
                className="p-3 border-b border-gray-600 hover:bg-gray-600 rounded-md transition duration-300"
                whileHover={{ scale: 1.02 }}
              >
                <p className="text-sm">
                  <span
                    className={
                      tx.from.toLowerCase() === wallet.address.toLowerCase()
                        ? "text-red-400"
                        : "text-green-400"
                    }
                  >
                    {tx.from.toLowerCase() === wallet.address.toLowerCase()
                      ? "Sent"
                      : "Received"}
                  </span>
                  <span className="text-gray-300">
                    {" "}
                    {ethers.formatEther(tx.value)} ETH
                  </span>
                </p>
                <p className="text-xs text-gray-400">
                  ⛓️ Tx Hash: {tx.hash.substring(0, 10)}...
                  {tx.hash.slice(-6)}
                </p>
              </motion.div>
            ))
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}

export default App;
