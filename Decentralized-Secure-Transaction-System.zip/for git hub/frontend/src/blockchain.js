import { ethers } from "ethers";
import contractJSON from "./contracts/Payments.json"; // ✅ Ensure this path is correct

export const contractAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3"; // ✅ Export contract address
const contractABI = contractJSON.abi;

export const getEthereumContract = async () => {
  if (!window.ethereum) {
    alert("MetaMask not detected!");
    return null;
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();

  console.log("🔗 Contract Address:", contractAddress);
  console.log("📜 Contract ABI:", contractABI);

  const contract = new ethers.Contract(contractAddress, contractABI, signer);
  console.log("✅ Contract Loaded:", contract);

  return contract;
};
